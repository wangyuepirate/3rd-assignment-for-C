#include "bst.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define N_INPUT 3
#define STRSIZE 50
#define LINEBREAK 1

int mystrcmp(const void* a, const void* b);
char* myprintstr(const void* v);
void Prntwords(bst *b,bstnode *t,char *str);


int main(int argc,char *argv[])
{
   FILE *fp1,*fp2;
   char tmp[STRSIZE];
   char *words;
   bst *dict,*missp;

   if(argc != N_INPUT){
      ON_ERROR("Input number Error\n");
   }
   if((fp1 = fopen(argv[1],"r")) == NULL){
      ON_ERROR("Cannot Open File1\n");
    }
   if((fp2 = fopen(argv[2],"r")) == NULL){
      ON_ERROR("Cannot Open File2\n");
    }

   dict = bst_init(STRSIZE, mystrcmp, myprintstr);
   while(fscanf(fp1,"%s",tmp) != EOF){
      bst_insert(dict,tmp);
    }
   missp = bst_init(STRSIZE, mystrcmp, myprintstr);
   while(fscanf(fp2,"%s",tmp) != EOF){
      if((bst_isin(dict,tmp)) == false){
         bst_insert(missp,tmp);          
       }
    }
    words=(char *)calloc(bst_size(missp)*(missp->elsz+LINEBREAK+1),sizeof(char));
    if(words == NULL){
       ON_ERROR("Words allocation Error\n");
    }
    Prntwords(missp,missp->top,words);
    printf("%s",words);
   
    free(words);
    words = NULL;
    bst_free(&dict);
    bst_free(&missp);
    fclose(fp1);
    fclose(fp2);
    return 0;
} 

void Prntwords(bst *b,bstnode *t,char *str)
{
   char *nstr;
   if(b == NULL){
      ON_ERROR("Prntwords Error\n");
   }
   if(t == NULL){
      return ;
   }
   nstr = (char *)calloc(b->elsz+LINEBREAK, sizeof(char));
   if(nstr == NULL){
      ON_ERROR("Calloc for Prntmissp nstr failed\n");
   }
   sprintf(nstr,"%s\n",(b->prntnode)(t->data));
   strcat(str,nstr);
   free(nstr);
   nstr = NULL;
   Prntwords(b, t->left, str);
   Prntwords(b, t->right, str);

   return ;

}

char* myprintstr(const void* v)
{
   return (char*)v;
}

int mystrcmp(const void* a, const void* b)
{
   return strcmp(a, b);
}
