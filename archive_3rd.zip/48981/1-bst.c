#include "bst.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define BRACKETS 2

bstnode *node_create(bst *b);
void node_insert(bst *b,bstnode *t,void *v);
int node_count(bstnode *t);
int node_maxdepth(bstnode *t);
bool node_intree(bst *b, bstnode *t, void *v);
void node_free(bstnode **t);
void node_prnt(bst *b, bstnode *t,char *str);
void Inordertra(bst *b,bstnode *t,void *v,int *n);
void Findmiddle(bst *n, void *v, int l, int r);


bst* bst_init(int sz,
              int(*comp)(const void* a, const void* b),
              char*(*prnt)(const void* a)  )
{
   bst *l;
   l = (bst *)calloc(1, sizeof(bst));
   if(l == NULL){
      ON_ERROR("Creation of bst in bst_init Failed\n");
   }
   l->top = NULL;
   l->elsz = sz;
   l->compare = comp;
   l->prntnode = prnt;
   return l;   
}



void bst_insert(bst* b, void* v)
{
   if(b == NULL || v == NULL){
      ON_ERROR("Insert Error\n");
   }
   if(b->top == NULL){
      b->top = node_create(b);
      memcpy(b->top->data, v, b->elsz);
      return;
   }
   node_insert(b, b->top, v);
   return;
}

bstnode *node_create(bst *b)
{
   bstnode *p;
   p = (bstnode *)calloc(1, sizeof(bstnode));
   if(p == NULL){
      ON_ERROR("Creation of bstnode in Createnode Failed\n");
   }
   p->data = (void *)calloc(1, b->elsz);
   if(p->data == NULL){
      ON_ERROR("Creation of bstnode(data) in Createnode Failed\n");
   }   
   p->left = NULL;
   p->right = NULL;
   return p;
}

void node_insert(bst *b, bstnode *t, void *v)
{
   bstnode *p;
   if(b == NULL || t == NULL || v == NULL){
      ON_ERROR("Insert(node_insert) Error\n");
   }
   if((b->compare)(v, t->data) == 0){
      return;
   }

   if((b->compare)(v, t->data)<0){
      if(t->left == NULL){
         p = node_create(b);
         memcpy(p->data, v, b->elsz);
         t->left = p;
      }
      else{
         node_insert(b, t->left, v);
      }
   }
   else{
      if(t->right == NULL){
         p = node_create(b);
         memcpy(p->data, v, b->elsz);
         t->right = p;
      }
      else{
         node_insert(b, t->right, v);
      }
   }
   return;
}



int bst_size(bst* b){
   if(b == NULL){
      ON_ERROR("Calculation of Size Error\n");
   }
   return node_count(b->top);
}

int node_count(bstnode *t)
{
  if(t == NULL){
     return 0;
  }
  return (node_count(t->left)+node_count(t->right)+1);
}



int bst_maxdepth(bst* b)
{
   int max_depth;
   if(b == NULL){
      ON_ERROR("Calculation of Maxdepth Error\n");
   }
   if(b->top == NULL){
       return 0;
   }
   max_depth = node_maxdepth(b->top);
   return max_depth;
}

int node_maxdepth(bstnode *t)
{
   int lpath,rpath,mpath;
   if(t == NULL){
      return 0;
   }
   lpath = node_maxdepth(t->left);
   rpath = node_maxdepth(t->right);
   mpath = ((lpath > rpath) ? lpath : rpath);
   return mpath+1;
}



bool bst_isin(bst* b, void* v)
{
   if(b == NULL || v == NULL){
      ON_ERROR("Check isin Error\n");
   }
   if(b->top == NULL){
      return false;
   }
   return node_intree(b, b->top, v);
}

bool node_intree(bst *b, bstnode *t, void *v)
{
   if(t == NULL){
      return false;
   }
   if((b->compare)(v, t->data) == 0){
      return true;
   }
   if((b->compare)(v, t->data) < 0){
      return node_intree(b, t->left, v);
   }
   else{
      return node_intree(b, t->right, v);
   }
}



void bst_insertarray(bst* b, void* v, int n)
{
   int i;
   if(b == NULL || v == NULL){
      ON_ERROR("Insertarray Error\n");
   }
   if(n <= 0){
      ON_ERROR("The number of items Error\n");
   }
   for(i = 0;i < n;++i){
      bst_insert(b, (char *)v+(i*b->elsz));
   }
   return;
}



void bst_free(bst** p)
{
   bst *a = *p;
   node_free(&a->top);
   free(a);
   *p = NULL;
   return;
}

void node_free(bstnode **t)
{
   bstnode *a = *t;
   if(a!=NULL){
      node_free(&a->left);
      node_free(&a->right);
      free(a->data);
      free(a);
      *t = NULL;
   }
   return;
}

/***************************/
/* Advanced functionality  */
/***************************/
char* bst_print(bst* b)
{
   char *str;
   if(b == NULL){
      return "Empty bst\n";
   }
   str = (char *)calloc(bst_size(b)*(b->elsz+BRACKETS), sizeof(char));
   node_prnt(b, b->top, str);
   return str;
}

void node_prnt(bst *b, bstnode *t,char *str)
{
   char *nstr;
   if(t == NULL){
      return ;
   }
   nstr = (char *)calloc(b->elsz+BRACKETS, sizeof(char));
   if(nstr == NULL){
      ON_ERROR("Calloc for Prntnode nstr failed\n");
   }
   sprintf(nstr,"(%s",(b->prntnode)(t->data));
   strcat(str,nstr);
   free(nstr);
   nstr = NULL;
   node_prnt(b, t->left, str);
   node_prnt(b, t->right, str);
   strcat(str,")");
  
   return ;

}



void bst_getordered(bst* b, void* v)
{
   int *n;
   if(b == NULL || v == NULL){
      ON_ERROR("Getordered Error\n");
   }
   n = (int *)calloc(1, sizeof(int));
   if(n == NULL){
     ON_ERROR("Creation pointer in bst_getordered error\n");
   }
   *n = 0;
   Inordertra(b, b->top, v, n);
   free(n);
   n = NULL;
   return;
}


void Inordertra(bst *b,bstnode *t,void *v,int *n)
{
   if(t!=NULL){
      Inordertra(b, t->left, v, n);
      memcpy((char *)v+((*n)*b->elsz), t->data, b->elsz);
      (*n)++;
      Inordertra(b, t->right, v, n);
   }
   return;
}



bst* bst_rebalance(bst* b)
{
   bst *n;
   int s;
   void *v;
   n = bst_init(b->elsz, b->compare, b->prntnode);
   s = bst_size(b);
   v=(void *)calloc(1, s*b->elsz);
   if(v == NULL){
      ON_ERROR("Rebalance Error\n");
   }
   bst_getordered(b, v);
   Findmiddle(n, v, 0, s);
   free(v);
   v = NULL;
   return n;
}

void Findmiddle(bst *n, void *v, int l, int r)
{
   int m;
   if(l != r){
      m = (l+r)/2;
      bst_insert(n, (char *)v+m*n->elsz);
      Findmiddle(n, v, l, m);
      Findmiddle(n, v, m+1, r);
   }
   return;
}
